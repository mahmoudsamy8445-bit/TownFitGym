import { createServerFn } from '@tanstack/react-start';
import { getRequest, setResponseHeader } from '@tanstack/react-start/server';
import { z } from 'zod';
import { bindings } from '../bindings.server';

type User = { id: string; email: string; name: string; role: string };
const db = () => {
  const { DB } = bindings();
  if (!DB) throw new Error('قاعدة البيانات غير مفعّلة. راجع إعدادات الموقع.');
  return DB;
};
const cookieName = 'townfit_session';
const cookie = (value: string, maxAge: number) => `${cookieName}=${value}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
const readToken = () => {
  const raw = getRequest().headers.get('cookie') ?? '';
  const found = raw.split(';').map((part) => part.trim()).find((part) => part.startsWith(`${cookieName}=`));
  return found?.slice(cookieName.length + 1) ?? '';
};
async function currentUser(): Promise<User | null> {
  const token = readToken();
  if (!token) return null;
  return (await db().prepare(`SELECT u.id, u.email, u.name, u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=? AND s.expires_at > datetime('now')`).bind(token).first<User>()) ?? null;
}
async function requireUser() {
  const user = await currentUser();
  if (!user) throw new Error('انتهت الجلسة. سجل الدخول مرة أخرى.');
  return user;
}
async function passwordHash(password: string, saltHex?: string) {
  const salt = saltHex ? Uint8Array.from(saltHex.match(/.{1,2}/g)!.map((v) => parseInt(v, 16))) : crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' }, key, 256);
  const hex = (bytes: Uint8Array) => Array.from(bytes).map((b) => b.toString(16).padStart(2, '0')).join('');
  return `${hex(salt)}:${hex(new Uint8Array(bits))}`;
}
async function verifyPassword(password: string, stored: string) {
  const [salt, expected] = stored.split(':');
  if (!salt || !expected) return false;
  const actual = (await passwordHash(password, salt)).split(':')[1];
  if (!actual || actual.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < actual.length; i++) diff |= actual.charCodeAt(i) ^ expected.charCodeAt(i);
  return diff === 0;
}
async function createSession(user: User) {
  const token = crypto.randomUUID();
  await db().prepare(`INSERT INTO sessions (id,user_id,expires_at) VALUES (?,?,datetime('now','+7 days'))`).bind(token, user.id).run();
  setResponseHeader('Set-Cookie', cookie(token, 604800));
  return { user };
}

export const authStatus = createServerFn({ method: 'GET' }).handler(async () => {
  const user = await currentUser();
  const setup = await db().prepare('SELECT COUNT(*) AS n FROM setup_guard').first<{ n: number }>();
  return { user, needsSetup: (setup?.n ?? 0) === 0 };
});

export const setupOwner = createServerFn({ method: 'POST' }).validator(z.object({ name: z.string().trim().min(2).max(80), email: z.string().trim().email().max(160), password: z.string().min(10).max(128) })).handler(async ({ data }) => {
  const database = db();
  const id = crypto.randomUUID();
  const hash = await passwordHash(data.password);
  try {
    await database.batch([
      database.prepare('INSERT INTO setup_guard (id) VALUES (1)'),
      database.prepare('INSERT INTO users (id,email,name,password_hash,role) VALUES (?,?,?,?,?)').bind(id, data.email.toLowerCase(), data.name, hash, 'owner'),
    ]);
  } catch {
    throw new Error('تم إعداد حساب المدير بالفعل، سجل الدخول.');
  }
  return createSession({ id, email: data.email.toLowerCase(), name: data.name, role: 'owner' });
});

export const login = createServerFn({ method: 'POST' }).validator(z.object({ email: z.string().trim().email().max(160), password: z.string().min(1).max(128) })).handler(async ({ data }) => {
  const email = data.email.toLowerCase();
  const attempts = await db().prepare(`SELECT COUNT(*) AS n FROM auth_attempts WHERE email=? AND attempted_at > datetime('now','-15 minutes')`).bind(email).first<{n:number}>();
  if ((attempts?.n ?? 0) >= 8) throw new Error('محاولات تسجيل الدخول كثيرة. انتظر 15 دقيقة ثم حاول مرة أخرى.');
  const row = await db().prepare('SELECT id,email,name,role,password_hash FROM users WHERE email=? COLLATE NOCASE').bind(email).first<User & { password_hash: string }>();
  if (!row || !(await verifyPassword(data.password, row.password_hash))) {
    await db().prepare('INSERT INTO auth_attempts(email) VALUES(?)').bind(email).run();
    throw new Error('البريد الإلكتروني أو كلمة المرور غير صحيحة.');
  }
  await db().prepare('DELETE FROM auth_attempts WHERE email=?').bind(email).run();
  return createSession({ id: row.id, email: row.email, name: row.name, role: row.role });
});

export const logout = createServerFn({ method: 'POST' }).handler(async () => {
  const token = readToken();
  if (token) await db().prepare('DELETE FROM sessions WHERE id=?').bind(token).run();
  setResponseHeader('Set-Cookie', cookie('', 0));
  return { ok: true };
});

export const getWorkspace = createServerFn({ method: 'GET' }).handler(async () => {
  const user = await requireUser();
  const database = db();
  const [members, trainers, subscriptions, attendance, payments, expenses, settings, leads, activeMembers, todayVisits, monthRevenue, expiring] = await Promise.all([
    database.prepare(`SELECT m.*, (SELECT s.end_date FROM subscriptions s WHERE s.member_id=m.id ORDER BY s.end_date DESC LIMIT 1) AS end_date, (SELECT s.plan_name FROM subscriptions s WHERE s.member_id=m.id ORDER BY s.end_date DESC LIMIT 1) AS plan_name FROM members m ORDER BY m.created_at DESC LIMIT 150`).all(),
    database.prepare('SELECT * FROM trainers ORDER BY name LIMIT 100').all(),
    database.prepare(`SELECT s.*,m.name AS member_name,m.phone AS member_phone FROM subscriptions s JOIN members m ON m.id=s.member_id ORDER BY s.end_date DESC LIMIT 150`).all(),
    database.prepare(`SELECT a.id,a.member_id,datetime(a.check_in_at,'+2 hours') AS check_in_at,a.recorded_by,m.name AS member_name,m.phone AS member_phone FROM attendance a JOIN members m ON m.id=a.member_id ORDER BY a.check_in_at DESC LIMIT 100`).all(),
    database.prepare(`SELECT p.id,p.member_id,p.amount,p.method,p.category,p.note,datetime(p.paid_at,'+2 hours') AS paid_at,p.recorded_by,m.name AS member_name FROM payments p LEFT JOIN members m ON m.id=p.member_id ORDER BY p.paid_at DESC LIMIT 100`).all(),
    database.prepare(`SELECT id,title,amount,category,datetime(spent_at,'+2 hours') AS spent_at,recorded_by FROM expenses ORDER BY spent_at DESC LIMIT 100`).all(),
    database.prepare('SELECT * FROM gym_settings WHERE id=1').first(),
    database.prepare('SELECT * FROM public_leads ORDER BY created_at DESC LIMIT 200').all(),
    database.prepare(`SELECT COUNT(DISTINCT m.id) AS n FROM members m JOIN subscriptions s ON s.member_id=m.id WHERE m.status='active' AND s.end_date >= date('now','+2 hours') AND s.status='active'`).first<{n:number}>(),
    database.prepare(`SELECT COUNT(*) AS n FROM attendance WHERE date(check_in_at,'+2 hours')=date('now','+2 hours')`).first<{n:number}>(),
    database.prepare(`SELECT COALESCE(SUM(amount),0) AS n FROM payments WHERE strftime('%Y-%m',paid_at,'+2 hours')=strftime('%Y-%m','now','+2 hours')`).first<{n:number}>(),
    database.prepare(`SELECT COUNT(*) AS n FROM subscriptions WHERE status='active' AND end_date BETWEEN date('now','+2 hours') AND date('now','+2 hours','+7 days')`).first<{n:number}>(),
  ]);
  return { user, members: (members.results ?? []) as any[], trainers: (trainers.results ?? []) as any[], subscriptions: (subscriptions.results ?? []) as any[], attendance: (attendance.results ?? []) as any[], payments: (payments.results ?? []) as any[], expenses: (expenses.results ?? []) as any[], settings: settings as any, leads: (leads.results ?? []) as any[], metrics: { activeMembers: activeMembers?.n ?? 0, todayVisits: todayVisits?.n ?? 0, monthRevenue: monthRevenue?.n ?? 0, expiring: expiring?.n ?? 0 } };
});

export const createMember = createServerFn({ method: 'POST' }).validator(z.object({ name:z.string().trim().min(2).max(100), phone:z.string().trim().min(7).max(25), email:z.string().email().max(160).optional().or(z.literal('')), gender:z.string().max(20).optional(), birth_date:z.string().max(10).optional(), notes:z.string().max(1000).optional(), plan_name:z.string().trim().min(2).max(80), start_date:z.string().regex(/^\d{4}-\d{2}-\d{2}$/), end_date:z.string().regex(/^\d{4}-\d{2}-\d{2}$/), price:z.number().min(0).max(1000000) }).refine((v)=>v.end_date>=v.start_date,{message:'تاريخ الانتهاء يجب أن يكون بعد تاريخ البداية.'})).handler(async ({data}) => {
  const user = await requireUser(); const id=crypto.randomUUID(); const sub=crypto.randomUUID();
  await db().batch([
    db().prepare('INSERT INTO members (id,name,phone,email,gender,birth_date,notes) VALUES (?,?,?,?,?,?,?)').bind(id,data.name,data.phone,data.email || null,data.gender || null,data.birth_date || null,data.notes || null),
    db().prepare('INSERT INTO subscriptions (id,member_id,plan_name,start_date,end_date,price) VALUES (?,?,?,?,?,?)').bind(sub,id,data.plan_name,data.start_date,data.end_date,data.price),
  ]);
  return {ok:true,id,user:user.name};
});

export const createSubscription = createServerFn({method:'POST'}).validator(z.object({member_id:z.string().uuid(),plan_name:z.string().trim().min(2).max(80),start_date:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),end_date:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),price:z.number().min(0).max(1000000)}).refine((v)=>v.end_date>=v.start_date,{message:'تاريخ الانتهاء يجب أن يكون بعد تاريخ البداية.'})).handler(async({data})=>{await requireUser();const member=await db().prepare('SELECT id FROM members WHERE id=?').bind(data.member_id).first();if(!member)throw new Error('العضو غير موجود.');await db().prepare(`UPDATE subscriptions SET status='expired' WHERE member_id=? AND status='active'`).bind(data.member_id).run();await db().prepare('INSERT INTO subscriptions(id,member_id,plan_name,start_date,end_date,price) VALUES(?,?,?,?,?,?)').bind(crypto.randomUUID(),data.member_id,data.plan_name,data.start_date,data.end_date,data.price).run();await db().prepare(`UPDATE members SET status='active',updated_at=datetime('now') WHERE id=?`).bind(data.member_id).run();return{ok:true};});

export const createTrainer = createServerFn({method:'POST'}).validator(z.object({name:z.string().trim().min(2).max(100),phone:z.string().max(25).optional(),specialty:z.string().max(100).optional(),monthly_salary:z.number().min(0).max(1000000)})).handler(async({data})=>{await requireUser();await db().prepare('INSERT INTO trainers(id,name,phone,specialty,monthly_salary) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),data.name,data.phone||null,data.specialty||null,data.monthly_salary).run();return{ok:true};});

export const recordAttendance = createServerFn({method:'POST'}).validator(z.object({member_id:z.string().uuid()})).handler(async({data})=>{const user=await requireUser();const valid=await db().prepare(`SELECT id FROM subscriptions WHERE member_id=? AND status='active' AND end_date>=date('now') ORDER BY end_date DESC LIMIT 1`).bind(data.member_id).first();if(!valid)throw new Error('لا يوجد اشتراك ساري لهذا العضو.');await db().prepare('INSERT INTO attendance(id,member_id,recorded_by) VALUES(?,?,?)').bind(crypto.randomUUID(),data.member_id,user.id).run();return{ok:true};});

export const addPayment = createServerFn({method:'POST'}).validator(z.object({member_id:z.string().optional(),amount:z.number().positive().max(1000000),method:z.enum(['cash','card','transfer']),category:z.enum(['subscription','private','other']),note:z.string().max(300).optional()})).handler(async({data})=>{const user=await requireUser();await db().prepare('INSERT INTO payments(id,member_id,amount,method,category,note,recorded_by) VALUES(?,?,?,?,?,?,?)').bind(crypto.randomUUID(),data.member_id||null,data.amount,data.method,data.category,data.note||null,user.id).run();return{ok:true};});

export const addExpense = createServerFn({method:'POST'}).validator(z.object({title:z.string().trim().min(2).max(100),amount:z.number().positive().max(1000000),category:z.string().max(80).optional()})).handler(async({data})=>{const user=await requireUser();await db().prepare('INSERT INTO expenses(id,title,amount,category,recorded_by) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),data.title,data.amount,data.category||null,user.id).run();return{ok:true};});

export const saveSettings = createServerFn({method:'POST'}).validator(z.object({gym_name:z.string().trim().min(2).max(100),monthly_price:z.number().min(0).max(100000),phone:z.string().max(25),address:z.string().max(250)})).handler(async({data})=>{await requireUser();await db().prepare(`UPDATE gym_settings SET gym_name=?,monthly_price=?,phone=?,address=?,updated_at=datetime('now') WHERE id=1`).bind(data.gym_name,data.monthly_price,data.phone,data.address).run();return{ok:true};});


// Public website registration: creates a pending request, never a paid membership.
export const createPublicLead = createServerFn({method:'POST'}).validator(z.object({name:z.string().trim().min(2).max(100),phone:z.string().trim().min(8).max(25).regex(/^[0-9+()\s-]+$/),plan_name:z.string().trim().min(2).max(100),price:z.number().positive().max(100000)})).handler(async({data})=>{
  const recent=await db().prepare("SELECT COUNT(*) AS n FROM public_leads WHERE phone=? AND created_at > datetime('now','-10 minutes')").bind(data.phone).first<{n:number}>();
  if((recent?.n ?? 0)>=2) throw new Error('تم استلام طلب بهذا الرقم مؤخرًا. تواصل معنا على واتساب للمساعدة.');
  const id=crypto.randomUUID();
  await db().prepare('INSERT INTO public_leads(id,name,phone,plan_name,price) VALUES(?,?,?,?,?)').bind(id,data.name,data.phone,data.plan_name,data.price).run();
  return {ok:true,id};
});

export const approveLead = createServerFn({method:'POST'}).validator(z.object({lead_id:z.string().uuid(),method:z.enum(['cash','transfer'])})).handler(async({data})=>{
  const user=await requireUser(); const database=db();
  const lead=await database.prepare("SELECT * FROM public_leads WHERE id=? AND status='pending'").bind(data.lead_id).first<{id:string;name:string;phone:string;plan_name:string;price:number}>();
  if(!lead) throw new Error('الطلب غير موجود أو تم التعامل معه بالفعل.');
  const existing=await database.prepare('SELECT id FROM members WHERE phone=? ORDER BY created_at DESC LIMIT 1').bind(lead.phone).first<{id:string}>();
  const id=existing?.id ?? crypto.randomUUID(), sub=crypto.randomUUID();
  const start=new Date(); const end=new Date(start);
  const days=lead.plan_name.includes('سنوي')?365:lead.plan_name.includes('6 شهور')?180:lead.plan_name.includes('3 شهور')?90:30;
  end.setDate(end.getDate()+days);
  const fmt=(d:Date)=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const statements=[] as any[];
  if(!existing) statements.push(database.prepare('INSERT INTO members(id,name,phone,notes) VALUES(?,?,?,?)').bind(id,lead.name,lead.phone,`طلب موقع عام ${lead.id} — بانتظار تسجيل الدفع`));
  statements.push(
    database.prepare('INSERT INTO subscriptions(id,member_id,plan_name,start_date,end_date,price) VALUES(?,?,?,?,?,?)').bind(sub,id,lead.plan_name,fmt(start),fmt(end),lead.price),
    database.prepare('INSERT INTO payments(id,member_id,amount,method,category,note,recorded_by) VALUES(?,?,?,?,?,?,?)').bind(crypto.randomUUID(),id,lead.price,data.method,'subscription',`طلب الموقع ${lead.id}`,user.id),
    database.prepare("UPDATE members SET status='active',updated_at=datetime('now') WHERE id=?").bind(id),
    database.prepare("UPDATE public_leads SET status='converted',converted_at=datetime('now') WHERE id=? AND status='pending'").bind(lead.id),
  );
  await database.batch(statements);
  return {ok:true,member_id:id,user:user.name};
});
