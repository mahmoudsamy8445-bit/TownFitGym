import { createFileRoute } from '@tanstack/react-router';
import { useMemo, useState } from 'react';
import { createPublicLead } from '../lib/api/townfit.functions';

export const Route = createFileRoute('/')({ component: PublicTownFit });

const plans = [
  { name: 'اشتراك شهر', price: 500, old: 750, perks: ['حصة Private مجانية'], tag: 'ابدأ دلوقتي' },
  { name: 'اشتراك 3 شهور', price: 1350, old: 2200, perks: ['دعوتان مجانيتان', 'أسبوع Free', 'أسبوع Freeze', 'حصتان Private'], tag: 'اختيار عملي' },
  { name: 'اشتراك 6 شهور', price: 2200, old: 3200, perks: ['4 دعوات مجانية', 'أسبوعان Free', 'أسبوعان Freeze', '3 حصص Private'], tag: 'قيمة أكبر' },
  { name: 'اشتراك سنوي', price: 3000, old: 5200, perks: ['8 دعوات مجانية', 'شهر Free', 'شهر Freeze', '4 حصص Private'], tag: 'أفضل توفير' },
];
const privateServices = [
  { name: 'باقة Private – 10 حصص', price: '1,250', old: '2,500', note: 'الصلاحية 15 يوم' },
  { name: 'باقة Private – 20 حصة', price: '1,850', old: '2,500', note: 'الصلاحية شهر' },
  { name: 'باقة Private – 30 حصة', price: '3,000', old: '4,500', note: 'الصلاحية 45 يوم' },
  { name: 'حصة Private منفردة', price: '200', old: '350' },
];
const inbodyServices = [
  { name: 'InBody لغير العملاء', price: '150', old: '200', note: 'قياس وتحليل مكونات الجسم' },
  { name: 'InBody لعملاء الجيم', price: '100', old: '150', note: 'سعر خاص لأعضاء Town Fit Gym' },
];
const extraServices: { name: string; price: string; old: string; note?: string }[] = [
  { name: 'Fitness Trainer', price: '1,000', old: '1,500' },
  { name: 'نظام غذائي', price: '500', old: '1,000' },
  { name: 'PT Children – أقل من 14 سنة', price: '1,250', old: '1,750' },
  { name: 'إصدار كارت أول مرة / بدل فاقد', price: '50', old: '' },
];

function PublicTownFit() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [plan, setPlan] = useState(plans[0].name);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [whatsappUrl, setWhatsappUrl] = useState('');
  const selected = useMemo(() => plans.find((p) => p.name === plan) ?? plans[0], [plan]);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setError(''); setWhatsappUrl('');
    try {
      await createPublicLead({ data: { name, phone, plan_name: selected.name, price: selected.price } });
      const message = `مرحباً Town Fit Gym، أريد الاشتراك في ${selected.name} بسعر ${selected.price} جنيه.\nالاسم: ${name}\nرقم الهاتف: ${phone}\nبرجاء التواصل لتأكيد الاشتراك.`;
      setWhatsappUrl(`https://wa.me/201030940709?text=${encodeURIComponent(message)}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر إرسال الطلب. حاول مرة أخرى.');
    } finally { setBusy(false); }
  }

  return <div className="public-site" dir="rtl">
    <header className="public-nav"><a href="#home" className="public-brand"><span className="public-mark">T</span><span><b>Town Fit Gym</b><small>TRAIN SMARTER. LIVE STRONGER.</small></span></a><a className="public-nav-cta" href="#join">اشترك الآن</a></header>
      <nav className="section-tabs" aria-label="أقسام الموقع"><a href="#plans">اشتراكات الجيم</a><a href="#private">Private</a><a href="#inbody">InBody</a><a href="#extras">خدمات إضافية</a><a href="#location">العنوان والتواصل</a></nav>
    <main>
      <section className="public-hero" id="home"><div className="hero-copy"><span className="public-eyebrow">YOUR FITNESS. YOUR PACE.</span><h1>ابدأ رحلتك<br/><em>مع Town Fit Gym</em></h1><p>مكانك للتدريب، التطور، وتحقيق أهدافك. اختار الباقة المناسبة وابدأ خطوتك الأولى النهارده.</p><div className="hero-actions"><a className="public-primary" href="#plans">شوف الاشتراكات <span>←</span></a><a className="public-secondary" href="https://wa.me/201030940709" target="_blank" rel="noreferrer">كلمنا على واتساب</a></div><div className="hero-proof"><span>01 <small>أسعار واضحة</small></span><span>02 <small>باقات مرنة</small></span><span>03 <small>متابعة واهتمام</small></span></div></div><div className="hero-art"><div className="hero-art-ring"></div><div className="hero-art-word">TownFit<span>Gym</span></div><div className="hero-art-stamp">NO EXCUSES<br/>JUST RESULTS</div><div className="hero-red-bar"></div></div></section>

      <section className="public-section plans-section" id="plans"><div className="section-heading"><div><span className="public-eyebrow">MEMBERSHIP PLANS</span><h2>اختار اشتراكك</h2></div><p>أسعار وعروض Town Fit Gym الحالية بالجنيه المصري.</p></div><div className="public-plan-grid">{plans.map((p, i) => <article className={`public-plan-card ${i===3?'featured-plan':''}`} key={p.name}><span className="plan-tag">{p.tag}</span><h3>{p.name}</h3><div className="plan-price"><strong>{p.price.toLocaleString('en-US')}</strong><span>جنيه</span></div><div className="plan-old">بدلًا من <del>{p.old.toLocaleString('en-US')} ج</del></div><ul>{p.perks.map(x=><li key={x}><i>✓</i>{x}</li>)}</ul><a href="#join" onClick={()=>setPlan(p.name)} className="plan-cta">اطلب الاشتراك <span>←</span></a></article>)}</div><div className="single-class-offer"><div><span className="plan-tag">دخول يوم واحد</span><h3>دخول حصة</h3><p>لو حابب تجرب التمرين من غير اشتراك شهري.</p></div><div className="service-price"><strong>100 <small>جنيه</small></strong><del>250 ج</del></div></div></section>

      <section className="public-section services-section" id="private"><div className="section-heading"><div><span className="public-eyebrow">PRIVATE TRAINING</span><h2>باقات الـ Private</h2></div><p>اختار عدد الحصص المناسب لهدفك.</p></div><div className="services-grid">{privateServices.map((s)=><article className="service-card" key={s.name}><div><h3>{s.name}</h3>{s.note&&<small>{s.note}</small>}</div><div className="service-price"><strong>{s.price} <small>ج</small></strong>{s.old&&<del>{s.old} ج</del>}</div></article>)}</div></section>

      <section className="public-section" id="inbody"><div className="section-heading"><div><span className="public-eyebrow">BODY COMPOSITION</span><h2>خدمة InBody</h2></div><p>أسعار قياس InBody للأعضاء وغير الأعضاء.</p></div><div className="services-grid inbody-grid">{inbodyServices.map((s)=><article className="service-card" key={s.name}><div><h3>{s.name}</h3>{s.note&&<small>{s.note}</small>}</div><div className="service-price"><strong>{s.price} <small>ج</small></strong>{s.old&&<del>{s.old} ج</del>}</div></article>)}</div></section>

      <section className="public-section services-section" id="extras"><div className="section-heading"><div><span className="public-eyebrow">MORE SERVICES</span><h2>خدمات إضافية</h2></div><p>خدمات مساعدة لتكمل تجربتك في الجيم.</p></div><div className="services-grid">{extraServices.map((s)=><article className="service-card" key={s.name}><div><h3>{s.name}</h3>{s.note&&<small>{s.note}</small>}</div><div className="service-price"><strong>{s.price} <small>ج</small></strong>{s.old&&<del>{s.old} ج</del>}</div></article>)}</div></section>

      <section className="join-section" id="join"><div className="join-intro"><span className="public-eyebrow">START HERE</span><h2>جاهز تبدأ؟</h2><p>سجل بياناتك واختار الباقة. طلبك هيوصل لإدارة الجيم، وبعدها تقدر تكمل التواصل معانا على واتساب لتأكيد التفاصيل والدفع.</p><div className="join-contact"><span>اتصال / واتساب</span><b dir="ltr">01030940709</b></div></div><div className="join-form-wrap">{whatsappUrl ? <div className="join-success"><span className="success-check">✓</span><h3>تم تسجيل طلبك بنجاح</h3><p>بياناتك وصلت لإدارة Town Fit Gym. افتح واتساب لإرسال رسالة التأكيد ومتابعة طلبك.</p><a href={whatsappUrl} target="_blank" rel="noreferrer" className="public-primary">إرسال الطلب على واتساب <span>↗</span></a><button onClick={()=>{setWhatsappUrl('');setName('');setPhone('');}} className="reset-form">تسجيل طلب جديد</button></div> : <form className="public-join-form" onSubmit={submit}><h3>طلب اشتراك جديد</h3><label>الاسم بالكامل<input required minLength={2} maxLength={100} value={name} onChange={e=>setName(e.target.value)} placeholder="اكتب اسمك"/></label><label>رقم الموبايل<input required minLength={8} maxLength={25} type="tel" value={phone} onChange={e=>setPhone(e.target.value)} placeholder="01xxxxxxxxx"/></label><label>اختار الاشتراك<select value={plan} onChange={e=>setPlan(e.target.value)}>{plans.map(p=><option key={p.name} value={p.name}>{p.name} – {p.price.toLocaleString('en-US')} جنيه</option>)}</select></label><div className="selected-plan-total"><span>قيمة الاشتراك المختار</span><b>{selected.price.toLocaleString('en-US')} جنيه</b></div>{error&&<p className="public-form-error">{error}</p>}<button disabled={busy} className="public-primary submit-public">{busy?'جاري تسجيل الطلب...':'سجل طلب الاشتراك'} <span>←</span></button><small className="privacy-note">تسجيل الطلب لا يعني تفعيل اشتراك مدفوع. يتم التأكيد بعد مراجعة الإدارة وإتمام الدفع.</small></form>}</div></section>

      <section className="location-section" id="location"><div className="public-location"><div><span className="public-eyebrow">FIND US</span><h2>مستنيينك في TownFitGym</h2><p>574 – المجاورة الثانية، خلف البريد، فيلا 574، القاهرة الجديدة.</p><div className="location-actions"><a href="tel:01030940709">اتصل بينا: 01030940709</a><a href="https://wa.me/201030940709" target="_blank" rel="noreferrer">واتساب</a><a href="https://www.google.com/maps/search/?api=1&query=Town+Fit+Gym%2C+Villa+574%2C+Second+Neighborhood%2C+behind+the+Post+Office%2C+New+Cairo%2C+Egypt" target="_blank" rel="noreferrer">افتح الاتجاهات على Google Maps ↗</a></div></div></div><div className="location-map-wrap"><iframe title="موقع TownFitGym على Google Maps" src="https://www.google.com/maps?q=Town%20Fit%20Gym%2C%20Villa%20574%2C%20Second%20Neighborhood%2C%20behind%20the%20Post%20Office%2C%20New%20Cairo%2C%20Egypt&output=embed" loading="lazy" referrerPolicy="no-referrer-when-downgrade" allowFullScreen /></div></section>
    </main>
    <footer className="public-footer"><a href="#home" className="public-brand"><span className="public-mark">T</span><span><b>Town Fit Gym</b><small>TRAIN SMARTER. LIVE STRONGER.</small></span></a><div>الدفع: كاش أو InstaPay على رقم <b dir="ltr">01118186598</b></div><a href="https://www.facebook.com/share/1FTT7Wi5qE/" target="_blank" rel="noreferrer">تابعنا على Facebook ↗</a><a href="/admin">دخول الإدارة</a><small>© {new Date().getFullYear()} Town Fit Gym. All rights reserved.</small></footer>
  </div>;
}
