CREATE TABLE IF NOT EXISTS public_leads (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  plan_name TEXT NOT NULL,
  price REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'converted', 'cancelled')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  converted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_public_leads_status ON public_leads(status, created_at);

UPDATE gym_settings
SET phone = '01030940709',
    address = '574، المجاورة الثانية، خلف البريد، فيلا 574'
WHERE id = 1;
