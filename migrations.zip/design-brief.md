# Town Fit Gym Management — Design Brief

- Design read: A private, Arabic-first operations workspace for the owner and front-desk team of Town Fit Gym; calm, decisive, legible, and built for daily speed.
- Concept spine: The control room. Every screen is a clear operational station with a consistent rail, status language, and data hierarchy.
- Delivery tier: editorial. Static-first, low-motion admin interface with direct feedback and dense but readable data.
- Animation mode: non-animated — user picked Non-animated at intake.
- Theme paradigm: Deep Dark, grounded in gym equipment and the existing black/red/white brand.
- Background character: solid charcoal surfaces with subtle tonal depth; no glow effects.
- Typography character: clean grotesk, Arabic system sans with a compact mono treatment for IDs and amounts.
- Locked palette: #111315 base, #1B1E21 raised surfaces, #292D31 borders, #F4F5F6 primary text, #A4A9AE secondary text, #D72F3F single accent. The red is the established brand accent and is used for primary actions and urgent states only.
- Locked type: system Arabic sans (Tajawal if available, otherwise system sans) + ui-monospace for identifiers and financial figures.
- Hero architecture: operational dashboard opening with a concise greeting, one clear add-member action, and a data-first overview. No marketing hero.
- Section system: Swiss grid discipline with distinct table, split-chart, and stacked-detail compositions.
- Signature components: compact metric strip; dense searchable member table; red-accented status ledger; vertical section navigation.
- Narrative spine motif: control-room stations, each module sharing the same frame and status vocabulary.
- Second-read moment: a narrow red vertical rail on the active navigation item.
- Section plan: Overview dashboard; Members directory; Subscriptions register; Attendance log; Trainers workspace; Finance ledger; Reports; Settings.
- Asset plan: custom monogram/favicon SVG, branded app mark, CSS-native data visualizations and functional iconography. Higgsfield-generated image assets could not be submitted because the connected generation service returned an account-tier restriction; no stock imagery or fabricated photos will be used in this data-first application.
- CTA inventory: Add member (red filled action); Record attendance (compact outlined action); Add payment (ledger action); Export report (text action); Save settings (red filled action).
- Responsive behavior: desktop sidebar and content grid; tablet collapses the sidebar; mobile uses a compact top bar and horizontally scrollable section navigation with single-column content.
